package zAssignment6;

import zAssignment6.BinaryHeap;
import zAssignment6.HuffmanNode;
import zAssignment6.HuffmanTree;

public class HuffmanTree {
    HuffmanNode root;

    public HuffmanTree(HuffmanNode huff) {
        this.root = huff;
    }

    public void printLegend() {
        printLegend(root, "");
    }

    private void printLegend(HuffmanNode h, String s) {
        if (h.letter.length() > 1) {
            printLegend(h.left, s + "0");
            printLegend(h.right, s + "1");
        } else {
            System.out.println(h.letter + "=" + s);
        }
    }

    public static BinaryHeap<HuffmanNode> legendToHeap(String legend) { 
        BinaryHeap<HuffmanNode> bh = new BinaryHeap<>();
        String[] s = legend.split(" ");

        for (int i = 0; i < s.length; i += 2) { 
            String letter = s[i];
            double frequency = Double.parseDouble(s[i + 1]);
            bh.insert(new HuffmanNode(letter, frequency));
        }
        return bh;
    }
    
    public static HuffmanTree createFromHeap(BinaryHeap<HuffmanNode> b) {
        while (b.getSize() > 1) {
            HuffmanNode left = (HuffmanNode) b.deleteMin();
            HuffmanNode right = (HuffmanNode) b.deleteMin();
            HuffmanNode pa = new HuffmanNode(left, right);
            b.insert(pa);
        }
        return new HuffmanTree((HuffmanNode) b.deleteMin());
    }
    
    public static void main(String[] args) {
    	// Example legend: characters and their frequencies
    	String legend = "V 1 W 2 G 3 H 4 N 5 L 6 S 8 O 10";
    	BinaryHeap<HuffmanNode> bh = legendToHeap(legend);
    	HuffmanTree htree = createFromHeap(bh);
    	htree.printLegend();
    }
}

