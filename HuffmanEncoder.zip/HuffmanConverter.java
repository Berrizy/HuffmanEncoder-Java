package zAssignment6;

import java.io.File;  
import java.io.FileNotFoundException;  
import java.util.Scanner;


public class HuffmanConverter{


        public static final int NUMBER_OF_CHARACTERS = 256;

        private String contents;
        private HuffmanTree huffmanTree;
        private int count[];
        private String code[];


        public HuffmanConverter(String input) {
          this.contents = input;
          this.count = new int[NUMBER_OF_CHARACTERS];
          this.code = new String[NUMBER_OF_CHARACTERS];
        }


        public void recordFrequencies() {
        	for (int i = 0; i < contents.length(); i++) {
            	char c = contents.charAt(i);
            	count[(int) c]++;
            }
        }

        
        public void frequenciesToTree() {
        	BinaryHeap<HuffmanNode> heap = new BinaryHeap<>();
        	for(int i = 0; i < NUMBER_OF_CHARACTERS; i++) {
        		if (count[i] > 0) {
        			String letter = "" + (char) i;
        			double freq = count[i];
        			heap.insert(new HuffmanNode(letter, freq));
        		}
        	}
        	huffmanTree = HuffmanTree.createFromHeap(heap);
        }


        
        public void treeToCode() {
        	treeToCode(huffmanTree.root, "");
        	
        }

        private void treeToCode(HuffmanNode t, String encoding) {
        	if (t.letter.length() == 1) {
        		code[(int) t.letter.charAt(0)] = encoding; 
        	}
        	else {
        		treeToCode(t.left, encoding + "0");
        		treeToCode(t.right, encoding + "1");
        	}
        }


        public String encodeMessage() {
        	StringBuilder sb = new StringBuilder();
        	for (int i = 0; i <contents.length();i++) {
        		sb.append(code[(int) contents.charAt(i)]);
        	}
        	return sb.toString();
        }
        

        public String decodeMessage(String encodedStr) {
        	StringBuilder deC = new StringBuilder();
        	HuffmanNode current = huffmanTree.root;
        	
        	for (int i = 0; i < encodedStr.length(); i++) {
        		char bit = encodedStr.charAt(i);
        		if (bit == '0') {
        			current = current.left;
        		}
        		else {
        			current = current.right;
        		}
        		if (current.letter.length() == 1) { 
        			deC.append(current.letter);
        			current = huffmanTree.root;
        		}
        	}
        	return deC.toString();
        }


        public static String readContents(String filename) {
            String temp = "";
            try {
                File file = new File(filename);
                Scanner sc = new Scanner(file);
                while (sc.hasNextLine()) {
                    temp += sc.nextLine();
                    temp += "\n";
                }
                sc.close();
                return temp;
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            return "";
        }

        public static void main(String args[]) {
        	
                String input = HuffmanConverter.readContents(args[0]);
                HuffmanConverter h = new HuffmanConverter(input);
                h.recordFrequencies();

                
                for (int i = 0; i < NUMBER_OF_CHARACTERS; i++) {
                	if (h.count[i] > 0) {
                		char c = (char) i;
                		String display;
                		if (c == '\n') {
                			display = "\\n";
    
                		}
                		else if(c == ' ') {
                			display = " ";
                		}
                		else {
                			display = String.valueOf(c);
                		}
                		System.out.print("<" + display + ", " + h.count[i] + "> ");
                	}
                }
                System.out.println();
                h.frequenciesToTree();
                h.treeToCode();
                

                
                System.out.println();
                for (int i = 0; i < NUMBER_OF_CHARACTERS; i++) {
                	if (h.code[i] != null) {
                		char c = (char) i;
                		String display;
                		if (c == '\n') {
                			display = "\\n";
    
                		}
                		else if(c == ' ') {
                			display = " ";
                		}
                		else {
                			display = String.valueOf(c);
                		}
                		System.out.println("'" + display + "'=" + h.code[i]);
                	}
                }
                System.out.println("\nHuffman Encoding:"); 
                String encoded = h.encodeMessage();
                System.out.println(encoded+"\n");
                System.out.println("Message size in ASCII encoding: "+h.contents.length()*8);
                System.out.println("Message size in Huffman coding: "+encoded.length()+"\n");
                System.out.println(h.decodeMessage(encoded));
        }

}

