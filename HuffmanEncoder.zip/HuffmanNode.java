package zAssignment6;

import zAssignment6.HuffmanNode;

public class HuffmanNode implements Comparable<HuffmanNode>{
    public String letter;
    public Double frequency;
    public HuffmanNode left, right;

    public HuffmanNode(String letter, Double frequency) {
        this.letter = letter;
        this.frequency = frequency;
        this.left = null;
        this.right = null;
    }

    public HuffmanNode(HuffmanNode left, HuffmanNode right) {
        this.letter = left.letter + right.letter;
        this.frequency = left.frequency + right.frequency;
        this.left = left;
        this.right = right;
    }

    public int compareTo(HuffmanNode o) {
        return this.frequency.compareTo(o.frequency);
    }

    public String toString() {
        return "<" + letter + ", " + frequency + ">";
    }
}

